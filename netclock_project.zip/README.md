# NetClock — Linux Networked Digital Clock

This project shows how to build a networked digital clock using C and Python on Linux.

## Build

```bash
gcc -pthread -o server server.c
gcc -o client client.c
```

## Run

Start the server:

```bash
./server
```

Connect locally with a client:

```bash
./client 127.0.0.1
```

Start the WebSocket relay:

```bash
python3 -m pip install websockets
python3 ws_relay.py
```

Serve index.html in a browser:

```bash
python3 -m http.server 8000
# Visit http://localhost:8000
```
