#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <server-ip> [port]\n", argv[0]);
        return 1;
    }
    char *host = argv[1];
    int port = (argc >= 3) ? atoi(argv[2]) : 12345;

    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) { perror("socket"); return 1; }

    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    if (inet_pton(AF_INET, host, &addr.sin_addr) <= 0) { perror("inet_pton"); return 1; }

    if (connect(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) { perror("connect"); return 1; }

    char buf[128];
    ssize_t r;
    while ((r = read(sock, buf, sizeof(buf)-1)) > 0) {
        buf[r] = '\0';
        fputs(buf, stdout);
        fflush(stdout);
    }

    close(sock);
    return 0;
}
