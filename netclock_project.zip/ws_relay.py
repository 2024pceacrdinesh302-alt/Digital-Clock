import asyncio
import websockets

TCP_HOST = '127.0.0.1'
TCP_PORT = 12345
WS_PORT = 8765

clients = set()

async def tcp_reader():
    while True:
        try:
            reader, writer = await asyncio.open_connection(TCP_HOST, TCP_PORT)
            print(f'Connected to TCP server {TCP_HOST}:{TCP_PORT}')
            while True:
                line = await reader.readline()
                if not line:
                    break
                msg = line.decode().rstrip('\n')
                if clients:
                    await asyncio.wait([ws.send(msg) for ws in clients])
        except Exception as e:
            print('TCP connection error:', e)
        print('Retrying TCP connection in 2s...')
        await asyncio.sleep(2)

async def ws_handler(websocket, path):
    clients.add(websocket)
    try:
        await websocket.wait_closed()
    finally:
        clients.remove(websocket)

async def main():
    server = await websockets.serve(ws_handler, '0.0.0.0', WS_PORT)
    print(f'WebSocket relay listening on ws://0.0.0.0:{WS_PORT}')
    await tcp_reader()

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print('relay stopped')
