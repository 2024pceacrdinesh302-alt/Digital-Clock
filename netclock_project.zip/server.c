#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <pthread.h>

#define PORT 12345
#define BACKLOG 10

void *client_thread(void *arg) {
    int client_fd = *(int*)arg;
    free(arg);

    while (1) {
        time_t t = time(NULL);
        struct tm tm = *localtime(&t);
        char buf[64];
        int len = snprintf(buf, sizeof(buf), "%02d:%02d:%02d\n", tm.tm_hour, tm.tm_min, tm.tm_sec);
        if (write(client_fd, buf, len) <= 0) break;
        sleep(1);
    }

    close(client_fd);
    return NULL;
}

int main() {
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) { perror("socket"); return 1; }

    int opt = 1;
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(PORT);

    if (bind(sockfd, (struct sockaddr*)&addr, sizeof(addr)) < 0) { perror("bind"); return 1; }
    if (listen(sockfd, BACKLOG) < 0) { perror("listen"); return 1; }

    printf("netclock server listening on port %d\n", PORT);

    while (1) {
        struct sockaddr_in client_addr;
        socklen_t len = sizeof(client_addr);
        int *client_fd = malloc(sizeof(int));
        *client_fd = accept(sockfd, (struct sockaddr*)&client_addr, &len);
        if (*client_fd < 0) { perror("accept"); free(client_fd); continue; }

        char ip[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &client_addr.sin_addr, ip, sizeof(ip));
        printf("client connected: %s:%d\n", ip, ntohs(client_addr.sin_port));

        pthread_t tid;
        pthread_create(&tid, NULL, client_thread, client_fd);
        pthread_detach(tid);
    }

    close(sockfd);
    return 0;
}
